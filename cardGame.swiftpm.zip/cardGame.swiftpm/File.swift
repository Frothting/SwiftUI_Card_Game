//
//  File.swift
//  cardGame
//
//  Created by Christian  Cordy on 7/28/22.
//

import Foundation
import SwiftUI

struct CardBack: View {
    var body: some View {
        Rectangle()
            .foregroundColor(.purple)
            .frame(width: 200, height: 300, alignment: .center)
    }
}

struct CardBack_Previews: PreviewProvider {
    static var previews: some View {
        CardBack()
    }
}
