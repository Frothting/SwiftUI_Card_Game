//
//  HandView.swift
//  cardGame
//
//  Created by Christian  Cordy on 7/31/22.
//

import SwiftUI
import LookingGlassUI

struct HandView: View {
    @State var exampleCard1 = Card(name: "Lil Sweater", description: "-This card can attact twice per turn \n -Attackers take 50% damage", type: .rock, rarity: .common, zPos: 1, personalityType: .shy, x: 100, y: 100)
    @State var selectedCard: Card?
    @ObservedObject var hand = Hand()
    @ObservedObject var deck = Deck()
    init() {
        hand.cards.append(exampleCard1)
    }
    var body: some View {
        VStack{
            Button("add card"){
                hand.cards.append(exampleCard1)
                print(hand.cards.count)
            }
            
            HStack(spacing: -100){
                ForEach(0..<hand.cards.count, id: \.self){ cardNum in
                    CardView2(card: hand.cards[cardNum], hand: hand)
                        .frame(width: 475 * (9/16), height: 475, alignment: .center)
                        .scaledToFit()
                }
            }
            
        }
    }
}

struct HandView_Previews: PreviewProvider {
    static var previews: some View {
        HandView()
    }
}
