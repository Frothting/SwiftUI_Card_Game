//
//  File 2.swift
//  cardGame
//
//  Created by Christian  Cordy on 7/29/22.
//

import Foundation
import SwiftUI

enum Rarities {
    case common
    case uncommon
    case rare
    case ultrarare
    
    var description: String {
        switch self {
        case .common:
            return "Common"
        case .uncommon:
            return "Uncommon"
        case .rare:
            return "Rare"
        case .ultrarare:
            return "Ultra Rare"
        }
    }
}

enum ViewState {
    case battle
    case homeMenu
}

enum Personalities: CaseIterable {
    case shy
    case aggressive
    case robotic
    case gooey
    case suspicious
    case testy
}

enum cardType {
    case rock
    case paper
    case scissors
}

struct Attack: Identifiable {
    var id = UUID()
    var name: String
    var type: cardType
    var baseDamage: Double
    
    init(name: String, type: cardType, baseDamage: Double) {
        self.name = name
        self.type = type
        self.baseDamage = baseDamage
    }
}


struct Card: Identifiable {
    var id = UUID()
    var name: String
    var description: String
    var rarity: Rarities
    var zPos: Double
    var touched: Bool = false
    var characterImage: Image
    var hp: Int = 10
    var maxHp: Int = 10
    var type: cardType
    var mp: Int = 0
    var coin: Int = 0
    
    var x: Double = 0
    var y: Double = 0
    
    var PP = [0,0,0,0]
    var attacks: [Attack] = []
    
    private var personalityType: Personalities
    
    
    
    init(name: String, description: String, type: cardType, rarity: Rarities, zPos: Double, personalityType: Personalities, x: Double, y: Double) {
        self.name = name
        self.description = description
        self.rarity = rarity
        self.zPos = zPos
        self.characterImage = Image("LilSweaterLads\(String(Int.random(in: 1...18)))")
        self.personalityType = personalityType
        self.type = type
        
        self.x = x
        self.y = y
        self.attacks.append( Attack(name: "sample attack", type: .rock, baseDamage: 1000.0))
    }
    
    mutating func incrementBy(amnt: Double){
        self.zPos += amnt
    }
    
    var shineColor: Color {
        switch rarity {
            case .common:
                return Color.clear
            case .uncommon:
                return Color.clear
            case .rare:
                return Color.white
            case .ultrarare:
                return Color.red
        }
    }
    
    var background: Image {
        switch self.rarity {
        case .common:
            return Image("commonBkg")
        case .uncommon:
            return Image("uncommonBkg")
        case .rare:
            return Image("rareBkg")
        case.ultrarare:
            return Image("ultraRareBkg")
        }
    }
    
    var personality: String {
        switch personalityType {
        case .shy:
            return "Shy"
        case .aggressive:
            return "Aggressive"
        case .robotic:
            return "Robotic"
        case .gooey:
            return "Gooey"
        case .suspicious:
            return "Suspicious"
        case .testy:
            return "Testy"
        }
    }
    
    mutating func takeDamage(amnt: Int){
        self.hp -= amnt
    }
}

class Hand: ObservableObject {
    @Published var cards: [Card]
    @Published var activeCardIndex = 0
    @Published var hp: Int = 10
    @Published var maxHp: Int = 10
    
    init() {
        self.cards = []
    }
    
    func getActiveCardType() -> cardType {
        return self.cards[self.activeCardIndex].type
    }
    
    func takeDamage(amount: Int) -> Bool { //returns true if the card should now be dead
        if self.cards.count > 0 {
            self.cards[activeCardIndex].takeDamage(amnt: amount)
            self.hp = self.cards[activeCardIndex].hp
        }
        
        if self.cards[activeCardIndex].hp <= 0 {
            return true
        } else {
            return false
        }
    }
    
    func calcDamage(attacker: Hand, attack: Attack) -> Int {
        if getActiveCardType() == attack.type {
            return Int(attack.baseDamage * 0.5)
        } else {
            return Int(attack.baseDamage)
        }
    }
}

class Deck: ObservableObject {
    @Published var cards: [Card]
    
    init() {
        self.cards = []
    }
    
}

extension View {
    /// Applies the given transform if the given condition evaluates to `true`.
    /// - Parameters:
    ///   - condition: The condition to evaluate.
    ///   - transform: The transform to apply to the source `View`.
    /// - Returns: Either the original `View` or the modified `View` if the condition is `true`.
    @ViewBuilder func `if`<Content: View>(_ condition: Bool, transform: (Self) -> Content) -> some View {
        if condition {
            transform(self)
        } else {
            self
        }
    }
}
