//
//  generateAttacks.swift
//  cardGame
//
//  Created by Christian  Cordy on 8/5/22.
//

import SwiftUI

func generateAttacks() -> [Attack] {
    var attacks = [Attack]()
    
    attacks.append(Attack(name: "paper", type: .paper, baseDamage: 1.0))
    attacks.append(Attack(name: "rock", type: .rock, baseDamage: 1.0))
    attacks.append(Attack(name: "scissors", type: .scissors, baseDamage: 1.0))
    attacks.append(Attack(name: "Spock", type: .rock, baseDamage: 20.0))
    
    return attacks
}
