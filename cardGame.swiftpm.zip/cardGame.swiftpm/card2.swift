//
//  File 2.swift
//  cardGame
//
//  Created by Christian  Cordy on 7/28/22.
//

import Foundation
import SwiftUI
import LookingGlassUI

struct CardView2: View {
    @State var card: Card
    @ObservedObject var hand: Hand
    
    var body: some View {
        VStack{
            //Spacer()
            ZStack{
                Text("\(hand.cards[hand.activeCardIndex].personality) \(hand.cards[hand.activeCardIndex].name)")
                    .foregroundColor(.white)
                    .offset(x: 1.0, y: 1.0)
                    .padding(.top, 8.0)
                    .padding(.horizontal, 5.0)
                    .font(.caption)
                Text("\(hand.cards[hand.activeCardIndex].personality) \(hand.cards[hand.activeCardIndex].name)")
                    .foregroundColor(.black)
                    .shimmer(color: card.rarity == .uncommon ? Color.yellow : Color.clear)
                    .shadow(color: .white, radius: 3.0, x: 1.0, y: 1.0)
                    .padding(.top, 8.0)
                    .padding(.horizontal, 5.0)
                    .font(.caption)
            }
            //Spacer()
            hand.cards[hand.activeCardIndex].characterImage
                .resizable()
                .shimmer(color: card.rarity == .rare ? Color.yellow : Color.clear)
                //.frame(width: 140, height: 140, alignment: .center)
            //.scaledToFit()
                .border(Color.black, width: 2.5)
                //.padding()
            
            Spacer()
            
            ZStack{
                Text("HP: \(hand.cards[hand.activeCardIndex].hp)| MP: \(hand.cards[hand.activeCardIndex].mp)| Coin: \(card.coin)")
                    .foregroundColor(.white)
                    .font(.caption)
                    .offset(x: 1.0, y: 1.0)
                    .shadow(color: .white, radius: 3.0)
                Text("HP: \(hand.cards[hand.activeCardIndex].hp)| MP: \(hand.cards[hand.activeCardIndex].mp)| Coin: \(hand.cards[hand.activeCardIndex].coin)")
                    .foregroundColor(.black)
                    .font(.caption)
            }
            
//            Text(card.description)
//                .frame(width: 135, height: 60, alignment: .center)
//                .font(.caption2)
//                .foregroundColor(.black)
//                .background(Color.white.cornerRadius(5.0))
//                .multilineTextAlignment(.leading)
//                .padding()
            Spacer()
        }
        .background(hand.cards[hand.activeCardIndex].background.resizable())
        //.scaledToFit()
        //.aspectRatio(1/2, contentMode: .fit)
        //.frame(width: 150, height: 150 * 1.5, alignment: .center)
        .border(.brown, width: 5.0)
        .cornerRadius(10.0)
        
    }
}
