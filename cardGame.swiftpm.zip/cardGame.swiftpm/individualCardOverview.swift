//
//  individualCardOverview.swift
//  cardGame
//
//  Created by Christian  Cordy on 8/8/22.
//

import SwiftUI
import LookingGlassUI

struct individualCardOverview: View {
    @State var card: Card = Card(name: "example", description: "description goes here", type: .rock, rarity: .ultrarare, zPos: 0, personalityType: .gooey, x: 0, y: 0)
    
    var body: some View {
        GeometryReader {geo in
            let h = geo.size.height
            let w = geo.size.width
            
            if w>h {
                HStack {
                    individualCard
                }
            } else {
                VStack{
                    individualCard
                }
            }
        }
    }
    
    var individualCard: some View {
        return Group {
            card.characterImage
                .resizable()
                .cornerRadius(50.0)
                .scaledToFit()
                .padding()
                .shimmer(color: card.shineColor)
                
            
            List {
                Section("Card Details"){
                    Text(card.name)
                    Text(card.description)
                    Text(card.rarity.description)
                }
                Section("Attacks"){
                    ForEach ( 0..<card.attacks.count){ att in
                        Text(card.attacks[att].name)
                    }
                }
            }
        }
    }
}

struct individualCardOverview_Previews: PreviewProvider {
    static var previews: some View {
        individualCardOverview()
            .previewInterfaceOrientation(.landscapeLeft)
    }
}
