import SwiftUI
import LookingGlassUI

@main
struct MyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .motionManager(updateInterval: 0.1, disabled: false)
        }
    }
}
