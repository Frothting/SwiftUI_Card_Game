import SwiftUI
import LookingGlassUI

struct ContentView: View {
    @State var ang = 0.00
    @State var playerCard = Card(name: "Lil Sweater", description: "", type: .scissors, rarity: .common, zPos: 1, personalityType: .robotic, x: 100, y: 100)
    @State var enemyCard = Card(name: "Evil Sweater", description: "", type: .rock, rarity: .ultrarare, zPos: 1, personalityType: .shy, x: 100, y: 100)
    @State var selectedCard: Card?
    @State var cardTapped = false
    @State var showCardDescription = false
    @State var popoverCard: Card?
    @State var wid: CGFloat = 100
    @State var showingText = false
    @State var textToShow = ["you attack...", "you deal x damage"]
    @State var showingTextIndex = 0
    @State var jiggle = 0.0
    @State var viewState: ViewState = .homeMenu
    @State var enemyIsDead = false
    
    @ObservedObject var hand = Hand()
    @ObservedObject var enemyHand = Hand()
    @ObservedObject var deck = Deck()
    
    let timer = Timer.publish(every: 0.1, on: .main, in: .common).autoconnect()
    
    init() {
        hand.cards.append(playerCard)
        enemyHand.cards.append(enemyCard)
    }
    
    var body: some View {
        VStack{
            switch viewState {
            case .battle:
                battleView
            case .homeMenu:
                homeMenu
            }
        }
        .animation(.easeIn)
    }
    
    func generateNewCard(){
        var newCard = Card(name: "a generated card", description: "there is a description here", type: .scissors, rarity: .ultrarare, zPos: Double(hand.cards.endIndex + 1), personalityType: Personalities.allCases.randomElement() ?? .shy, x: 1000, y: 1000)
        let rarityRoll = Int.random(in: 0..<100)
        
        if rarityRoll < 50 {
            newCard.rarity = .ultrarare
        } else if rarityRoll < 75 {
            newCard.rarity = .ultrarare
        } else if rarityRoll < 95 {
            newCard.rarity = .ultrarare
        } else if rarityRoll < 100 {
            newCard.rarity = .ultrarare
        }
        
        hand.cards.append(newCard)
        print(newCard)
    }
    
    var teamView: some View {
            
            return GeometryReader{ geo in
                List {
                    Button("Open new card") {
                        generateNewCard()
                    }
                    
                    ForEach(hand.cards){ c in
                        HStack{
                            c.characterImage
                                .resizable()
                                .scaledToFit()
                                .frame(width: 100, height: 100, alignment: .center)
                            NavigationLink(c.name){
                                individualCardOverview(card: c)
                            }
                        }
                    }
                }
            }
    }

    var homeMenu: some View {
        return NavigationView{
            List{
                NavigationLink("Team View"){
                    teamView
                        .navigationTitle("Team View")
                }
                .navigationViewStyle(.stack)
                
                Section("Actions"){
                    HStack{
                        Spacer()
                        Button("Find a Battle"){
                            viewState = .battle
                        }
                        Spacer()
                    }
                }
            }
            .navigationTitle(Text("Home"))
        }
        
    }
    
    var battleView: some View {
        return GeometryReader { geo in
            VStack(spacing: 0){
                
                //Enemy Card
                HStack{
                    Spacer()
                    healthBarViews(hand: enemyHand)
                        .frame(height: 20, alignment: .center)
                        .padding()
                        .animation(.easeOut(duration: 2.0))
                    Spacer()
                    CardView2(card: enemyHand.cards[enemyHand.activeCardIndex], hand: enemyHand)
                        .frame(width: (4/5) * (geo.size.height/3-20), height: (geo.size.height/3-20), alignment: .center)
                        .overlay(Image("sparkles").resizable().opacity(0.5).cornerRadius(15.0).blendMode(.lighten))
                        .padding()
                        //.rotationEffect(.degrees(jiggle))
                        .offset(x: jiggle, y: jiggle)
                        .animation(.spring(response: 0.15, dampingFraction: 0.3, blendDuration: 0.1), value: jiggle)
                        .shimmer(color: .yellow)
                }
                .shadow(color: .black, radius: 15.0, x: 5.0, y: 5.0)

                
                //Player Card
                HStack{
                    CardView2(card: hand.cards[enemyHand.activeCardIndex], hand: hand)
                        .frame(width: (4/5) * (geo.size.height/3-20), height: (geo.size.height/3-20), alignment: .center)
                        .padding()
                        .animation(.easeInOut)
                    healthBarViews(hand: hand)
                        .frame(height: 20, alignment: .center)
                        .padding(.trailing, 40)
                    Spacer()
                }
                .shadow(color: .black, radius: 15.0, x: 5.0, y: 5.0)
                Spacer()
                
                // The Text Shown after performing an action
                actionView
                    //.frame(height: geo.size.height/3, alignment: .center)
            }
            .background(
                Image("camo2")
                    .resizable(resizingMode: .tile)
                    .ignoresSafeArea())
        }
    }
    
    var switchView: some View {
        return List() {
            ForEach(0..<hand.cards.count){ crdInd in
                HStack{
                    
                    hand.cards[crdInd].characterImage
                        .resizable()
                        .frame(width: 50, height: 50, alignment: .center)
                    
                    Spacer()
                    Text(hand.cards[crdInd].name)
                }
                .onTapGesture {
                    hand.activeCardIndex = crdInd
                    print(hand.activeCardIndex)
                }
            }
        }
    }
    
    var actionView: some View {
        GeometryReader { geo in
            if showingText {
                VStack{
                    Spacer()
                    Text(textToShow[showingTextIndex]).frame(width: geo.size.width, alignment: .center)
                    Spacer()
                }
                .background(Color.gray)
                .onTapGesture {
                    if showingTextIndex < textToShow.count-1 {
                        withAnimation(){
                            showingTextIndex += 1
                        }
                    } else {
                        withAnimation(.easeInOut){
                            showingText = false
                        }
                    }
                }
            } else{ // The attacking button options
                NavigationView{
                    VStack(alignment: .leading, spacing: 5.0){
                        HStack{
                            NavigationLink("Attack"){
                                Form() {
                                    ForEach(generateAttacks()){ att in
                                        Button(att.name){
                                            // do something
                                            let damage = enemyHand.calcDamage(attacker: hand, attack: att)
                                            withAnimation(){
                                                enemyIsDead = enemyHand.takeDamage(amount: Int(damage))
                                                jiggle += Double(damage) * Double(Int.random(in: -50...50))
                                                
                                                if enemyIsDead {
                                                    DispatchQueue.main.asyncAfter(deadline: .now() + 4.0){
                                                        withAnimation{
                                                            viewState = .homeMenu
                                                        }
                                                    }
                                                }
                                            }
                                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1){
                                                withAnimation(){
                                                    jiggle = 0
                                                }
                                            }
                                            showingText = true
                                            textToShow = ["You use \(att.name)...", "You deal \(damage) damage...", "The enemy does nothing."]
                                            showingTextIndex = 0
                                        }
                                        .font(.body)
                                    }
                                }
                            }
                            Button("Item"){}
                      
                            NavigationLink("Switch"){
//                                    switchView
                                switchView
                            }
                            Button("Draw"){generateNewCard()}
                        }
                        Spacer()
                    }
                    .font(.title)
                }
                .navigationViewStyle(.stack)
                .border(Color.gray, width: 10.0)
                .cornerRadius(15.0, antialiased: true)
                .padding()
                .buttonStyle(.bordered)
                .navigationBarTitle(Text("What do you want to do?"))
                .shadow(color: .black, radius: 15.0, x: 5.0, y: 5.0)
            }
        }
        
    }
}
