//
//  healthBarViews.swift
//  cardGame
//
//  Created by Christian  Cordy on 8/5/22.
//

import SwiftUI

struct healthBarViews: View {
    @ObservedObject var hand: Hand
    var body: some View {
        GeometryReader{ geo in
            let wid = geo.size.width
            let ht = geo.size.height
            
            HStack(spacing: 0) {
                Rectangle().frame(width: 10, height: ht+20, alignment: .center)
                VStack(alignment: .leading){
                    Spacer()
                    HStack{
                        Rectangle()
                            .foregroundColor(.red)
                            .frame(width: wid * CGFloat(CGFloat(hand.hp)/CGFloat(hand.maxHp)), height: ht * 0.7, alignment: .center)
                            .clipShape(Capsule())
                        Spacer()
                    }
                    Spacer()
                    Rectangle()
                        .frame(width: wid, height: 10, alignment: .center)
                }
                
            }
            .padding()
        }
    }
}
