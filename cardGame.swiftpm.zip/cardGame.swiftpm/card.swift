//
//  File.swift
//  cardGame
//
//  Created by Christian  Cordy on 7/28/22.
//

import Foundation
import SwiftUI

struct CardView: View {
    var body: some View {
        ZStack{
            Rectangle()
                .aspectRatio(CGSize(width: 9,height: 16),contentMode: .fit)
                .shadow(color: .black, radius: 15.0, x: 2.0, y: 2.0)
                .border(.brown, width: 15.0)
                .cornerRadius(15.0)
                .foregroundColor(.yellow)
                
            
            VStack{
                //Title
                
                HStack{
                    Text("Card Name Here!")
                        .font(.title)
                        .padding(.horizontal, 20)
                        .cornerRadius(10.0)
                        .background(Color.gray)
                        .foregroundColor(.white)
                        .shadow(color: .gray, radius: 3.0, x: 1.0, y: 1.0)
                        .border(.black, width: 2.0)
                    Spacer()
                }
                .padding(.leading, 29)
                    
                
                Spacer()
                Image("img")
                    
                    .resizable()
                    .aspectRatio(CGSize(width: 1, height: 1), contentMode: .fit)
                    .border(.black, width: 2.0)
                    .padding(15.0)
                HStack {
                    //Spacer()
                    Text("att: 6")
                        .padding()
                    Text("def: 7")
                        .padding()
                    Text("hp: 10")
                        .padding()
                    //Spacer()
                }
                .background(Color.gray)
                .border(.black, width: 1.0)
                .padding(.horizontal, 20)
                
                
                VStack{
                    Text("card description goes here and continues on the next line more text goes here hahahaah hahahaah hahahaah hahahaah hahahaah hahahaah hahahaah hahahaah hahahaah hahahaah hahahaah hahahaah hahahaahhahahaah hahahaah hahahhahahaahhahahaah")
                        .padding()
                        .background(Color.gray)
                        .font(.body)
                        .border(.black, width: 2.0)
                }
                .padding(.horizontal, 20.0)
                
                
            }
            .aspectRatio(CGSize(width: 2, height: 3), contentMode: .fit)
        }
        
    }
}

struct CardView_Previews: PreviewProvider {
    static var previews: some View {
        CardView()
    }
}
